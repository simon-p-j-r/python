# 作者: 王道 龙哥
# 2022年06月08日11时55分36秒
import random

print(random.__file__)