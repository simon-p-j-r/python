# 作者: 王道 龙哥
# 2022年06月08日11时48分30秒
title = "模块1"


# 函数
def say_hello():
    print("我是模块1的sayhello")


# 类
class Dog(object):
    pass