# 作者: 王道 龙哥
# 2022年06月08日11时48分47秒
import wd_01_测试模块 as DogModule

DogModule.say_hello()
dog = DogModule.Dog()
print(dog)