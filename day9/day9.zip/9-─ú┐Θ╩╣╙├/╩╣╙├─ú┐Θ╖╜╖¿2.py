# 作者: 王道 龙哥
# 2022年06月08日11时50分45秒
from wd_01_测试模块 import say_hello
from wd_02_测试模块 import say_hello as say_hello2
say_hello()
say_hello2()