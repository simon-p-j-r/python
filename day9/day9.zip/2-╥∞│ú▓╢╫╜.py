# 作者: 王道 龙哥
# 2022年06月08日10时30分54秒

try:
    num=int(input('请输入一个数字:'))
    print(num)
except:
    print('请输入数字！')

